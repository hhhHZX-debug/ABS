# AES 5 round key recovery attack
This repo contains our implementation of Shamir's paper "Improved Key Recovery Attacks on Reduced-Round AES with Practical Data and
Memory Complexities". It contains the papers we surveyed on reduced-round aes and also contains the code for Grassi's implementation for his attack. 
